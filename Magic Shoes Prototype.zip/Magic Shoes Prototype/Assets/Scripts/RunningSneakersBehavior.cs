﻿using UnityEngine;
using System.Collections;

public class RunningSneakersBehavior : MonoBehaviour {

	private PlayerBehavior playerScript;		// used to get speed

	// Use this for initialization
	void Start () {
		playerScript = GetComponentInParent<PlayerBehavior> ();
	}

	void OnDisable () {
		playerScript.speed = 1f;
	}
	
	// Update is called once per frame
	void Update () {
		if (Input.GetKeyDown (KeyCode.Space) && playerScript.isGrounded) {
			playerScript.speed = 5f;
		} else if (Input.GetKeyUp (KeyCode.Space)) {
			playerScript.speed = 1f;
		}
	}
}
