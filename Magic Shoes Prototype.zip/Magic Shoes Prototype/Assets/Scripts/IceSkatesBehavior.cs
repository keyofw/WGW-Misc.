﻿using UnityEngine;
using System.Collections;

public class IceSkatesBehavior : MonoBehaviour {

	private bool skatesOn;			// detects whether you're using them or not

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
		if (Input.GetKeyDown (KeyCode.Space) && GetComponentInParent<PlayerBehavior> ().isGrounded) {
			SwitchSkates ();
		}
	}

	void SwitchSkates () {
		if (!skatesOn) {
			skatesOn = true;
			Debug.Log ("The skates are now working. Whatever that means.");
		} else {
			skatesOn = false;
			Debug.Log ("The skates are off now.");
		}
	}
}
