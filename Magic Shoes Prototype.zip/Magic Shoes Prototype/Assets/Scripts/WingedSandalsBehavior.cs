﻿using UnityEngine;
using System.Collections;

public class WingedSandalsBehavior : MonoBehaviour {

	private PlayerBehavior playerScript;			// get access to stuff
	private Rigidbody2D rgbd;						// get access to falling speed

	void Start () {
		playerScript = GetComponentInParent<PlayerBehavior> ();
		rgbd = GetComponentInParent<Rigidbody2D> ();
	}
	
	void Update () {
		if (Input.GetKey (KeyCode.Space) && playerScript.isGrounded == false) {
			rgbd.gravityScale = 0.1f;
		} else if (Input.GetKeyUp (KeyCode.Space)) {
			rgbd.gravityScale = 1f;
		}
	}
}
