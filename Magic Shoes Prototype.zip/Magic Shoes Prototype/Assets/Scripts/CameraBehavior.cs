﻿using UnityEngine;
using System.Collections;

public class CameraBehavior : MonoBehaviour {

	public GameObject Player;		//get the player

	[HideInInspector] public Vector2 playerLocation;	// for the player's location
	[HideInInspector] public Vector2 currentLocation;	// for the camera's location

	void Start () {
		playerLocation = Player.transform.position;		// set the player's location
		transform.position = new Vector3 (playerLocation.x, playerLocation.y, -10f); // set the camera position
		currentLocation = transform.position;
	}

	void Update () {
		// move the camera
		playerLocation = Player.transform.position;
		if (playerLocation.x - 1f > transform.position.x) {
			currentLocation = transform.position;
			currentLocation.x = playerLocation.x - 1f;
			transform.position = new Vector3 (currentLocation.x, currentLocation.y, -10f);
		} else if (playerLocation.x + 1f < transform.position.x) {
			currentLocation = transform.position;
			currentLocation.x = playerLocation.x + 1f;
			transform.position = new Vector3 (currentLocation.x, currentLocation.y, -10f);
		}
		if (playerLocation.y - 1.5f > transform.position.y) {
			currentLocation = transform.position;
			currentLocation.y = playerLocation.y - 1.5f;
			transform.position = new Vector3 (currentLocation.x, currentLocation.y, -10f);
		} else if (playerLocation.y + 1.5f < transform.position.y) {
			currentLocation = transform.position;
			currentLocation.y = playerLocation.y + 1.5f;
			transform.position = new Vector3 (currentLocation.x, currentLocation.y, -10f);
		}
	}
}
