﻿using UnityEngine;
using System.Collections;

// this spawns just to die
public class PowBehavior : MonoBehaviour {

	// Use this for initialization
	void Start () {
		StartCoroutine (kill());
	}

	IEnumerator kill () {
		yield return new WaitForSeconds(0.3f);
		Destroy (this.gameObject);
	}
}
