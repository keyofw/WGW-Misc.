﻿using UnityEngine;
using System.Collections;

public class StiltsBehavior : MonoBehaviour {

	private GameObject stiltsObject;	// the thing we want to activate
	private GameObject player;			// the player
	private Vector2 currentLocation;	// used only to switch stilts on and off
	private bool stiltsUp = false;		// whether the stilts are up or not

	void Start () {
		stiltsObject = transform.GetChild (0).gameObject;
		player = transform.parent.gameObject;
	}

	void OnEnable () {
		stiltsUp = false;
		stiltsObject.SetActive (false);
	}
	
	void Update () {
		if (Input.GetKeyDown (KeyCode.Space) && GetComponentInParent<PlayerBehavior> ().isGrounded) {
			SwitchStilts ();
		}
	}

	// runs what happens when you switch on and off
	void SwitchStilts () {
		if (!stiltsUp) {
			stiltsObject.SetActive (true);
			currentLocation = player.transform.position;
			currentLocation.y += 1.0f;
			player.transform.position = currentLocation;
			stiltsUp = true;
		} else {
			stiltsObject.SetActive (false);
			stiltsUp = false;
		}
	}
}
