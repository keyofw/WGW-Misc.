﻿using UnityEngine;
using System.Collections;

// THIS SCRIPT GETS ALL BEHAVIORS FOR THE PLAYER CHARACTER ONLY
// 1. Get character motion side to side
// 2. Get character motion up and down when climbing ladders
// 3. Switch character shoes
public class PlayerBehavior : MonoBehaviour {

	// the nine shoes
	public GameObject 	Ice_Skates, Winged_Sandals, Rocket_Greaves,
						Steel_Toed_Boots, Jump_Shoes, Spiked_Cleats,
						Stilts, Running_Sneakers, Magnetic_Slippers;

	public GameObject	Spawn_Point;	// where you spawn if you die

	// their scripts
	[HideInInspector] public IceSkatesBehavior IceSkatesScript;
	[HideInInspector] public WingedSandalsBehavior WingedSandalsScript;
	[HideInInspector] public RocketGreavesBehavior RocketGreavesScript;
	[HideInInspector] public SteelToedBootsBehavior SteelToedBootsScript;
	[HideInInspector] public JumpShoesBehavior JumpShoesScript;
	[HideInInspector] public SpikedCleatsBehavior SpikedCleatsScript;
	[HideInInspector] public StiltsBehavior StiltsScript;
	[HideInInspector] public RunningSneakersBehavior RunningSneakersScript;
	[HideInInspector] public MagneticSlippersBehavior MagneticSlippersScript;

	// other declarations
	[HideInInspector] public Vector2 currentLocation;				// where is the player?
	[HideInInspector] public Vector2 currentScale;					// which direction is the player facing?

	public GameObject LinecastCheck;								// the location for the linecast
	public float speed = 1f;										// how fast the player can move
	public bool isGrounded;											// if the character is on the ground
	public bool facingRight = true;									// if the character is facing right

	private GameObject CurrentShoes;								// the current pair of shoes you're using
	private float speedConstant = 0.08f;							// a constant to affect all speeds

	void Start () {
		// get scripts
		IceSkatesScript = GetComponent<IceSkatesBehavior> ();
		WingedSandalsScript = GetComponent<WingedSandalsBehavior> ();
		RocketGreavesScript = GetComponent<RocketGreavesBehavior> ();
		SteelToedBootsScript = GetComponent<SteelToedBootsBehavior> ();
		JumpShoesScript = GetComponent<JumpShoesBehavior> ();
		SpikedCleatsScript = GetComponent<SpikedCleatsBehavior> ();
		StiltsScript = GetComponent<StiltsBehavior> ();
		RunningSneakersScript = GetComponent<RunningSneakersBehavior> ();
		MagneticSlippersScript = GetComponent<MagneticSlippersBehavior> ();

	}

	// if you touch spikes, die
	void OnCollisionEnter2D (Collision2D col) {
		if (col.gameObject.tag == "Spikes") {
			KillPlayer ();
		}
	}

	void OnTriggerEnter2D (Collider2D col) {
		if (col.gameObject.tag == "Flag") {
			AnnounceWin ();
		}
	}

	void Update () {

		// detect if on the ground or not
		if (Physics2D.Linecast (new Vector2(LinecastCheck.transform.position.x - 0.5f, LinecastCheck.transform.position.y - 0.1f),
			new Vector2(LinecastCheck.transform.position.x + 0.5f, LinecastCheck.transform.position.y - 0.1f))) {
			isGrounded = true;
		} else {
			isGrounded = false;
		}
			
		// if you press one of these keys, you'll equip different shoes - if you are not in midair!
		if (isGrounded) {
			if (Input.GetKeyDown (KeyCode.Q)) {
				ChangeShoes (Ice_Skates);
			} else if (Input.GetKeyDown (KeyCode.W)) {
				ChangeShoes (Winged_Sandals);
			} else if (Input.GetKeyDown (KeyCode.E)) {
				ChangeShoes (Rocket_Greaves);
			} else if (Input.GetKeyDown (KeyCode.A)) {
				ChangeShoes (Steel_Toed_Boots);
			} else if (Input.GetKeyDown (KeyCode.S)) {
				ChangeShoes (Jump_Shoes);
			} else if (Input.GetKeyDown (KeyCode.D)) {
				ChangeShoes (Spiked_Cleats);
			} else if (Input.GetKeyDown (KeyCode.Z)) {
				ChangeShoes (Stilts);
			} else if (Input.GetKeyDown (KeyCode.X)) {
				ChangeShoes (Running_Sneakers);
			} else if (Input.GetKeyDown (KeyCode.C)) {
				ChangeShoes (Magnetic_Slippers);
			}
		}
			
	}

	void FixedUpdate () {
		// get location and check for player movement
		currentLocation = transform.position;

		// horizontal movement
		float h = Input.GetAxis("Horizontal");

		// flip sprite
		if (h > 0 && !facingRight) {
			facingRight = true;
			currentScale = transform.localScale;
			currentScale.x *= -1;
			transform.localScale = currentScale;
		} else if (h < 0 && facingRight) {
			facingRight = false;
			currentScale = transform.localScale;
			currentScale.x *= -1;
			transform.localScale = currentScale;
		}

		currentLocation.x += h * speed * speedConstant;
		transform.position = currentLocation;

	}

	// changes the active pair of shoes
	void ChangeShoes (GameObject shoe) {
		if (CurrentShoes != null) {
			CurrentShoes.SetActive (false);
		}
		CurrentShoes = shoe;
		CurrentShoes.SetActive(true);
	}

	void KillPlayer () {
		Vector2 spawnPoint = new Vector2 (Spawn_Point.transform.position.x, Spawn_Point.transform.position.y);
		transform.position = spawnPoint;
	}

	void AnnounceWin () {
		Vector2 spawnPoint = new Vector2 (Spawn_Point.transform.position.x, Spawn_Point.transform.position.y);
		transform.position = spawnPoint;
		Debug.Log ("SUCCESS");
	}
}
