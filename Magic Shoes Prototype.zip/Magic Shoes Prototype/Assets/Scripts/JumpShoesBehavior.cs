﻿using UnityEngine;
using System.Collections;

// Behavior for jumping.
public class JumpShoesBehavior : MonoBehaviour {

	private float jumpForce = 410f;				// how fast you jump

	// Use this for initialization
	void Start () {

	}

	// Update is called once per frame
	void Update () {
		if (Input.GetKeyDown(KeyCode.Space) && transform.parent.GetComponent<PlayerBehavior>().isGrounded) {
			Jump ();
		}
	}

	void Jump () {
		transform.parent.GetComponent<Rigidbody2D> ().AddForce (transform.up * jumpForce);
	}
}
