﻿using UnityEngine;
using System.Collections;

public class SpikedCleatsBehavior : MonoBehaviour {

	public GameObject Pow;					// the pow symbol

	private RaycastHit2D hit;				// for the destroying of ground

	// Update is called once per frame
	void Update () {
		if (Input.GetKeyDown(KeyCode.Space) && transform.parent.GetComponent<PlayerBehavior>().isGrounded) {
			Stomp ();
		}
	}

	void Stomp () {
		Instantiate (Pow, transform.GetChild (0).transform.position, Quaternion.identity);

		hit = Physics2D.Raycast (transform.GetChild (0).transform.position, Vector2.up, 0.01f);
		if (hit.collider != null) {
			Destroy (hit.collider.gameObject);
		}

	}
}
