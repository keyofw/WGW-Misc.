﻿using UnityEngine;
using System.Collections;

// Behavior for kicking.
public class SteelToedBootsBehavior : MonoBehaviour {

	public GameObject Pow;				// the graphic for kicking for this prototype

	private RaycastHit2D hit;			// the raycast for an attack

	// Update is called once per frame
	void Update () {
		if (Input.GetKeyDown(KeyCode.Space) && transform.parent.GetComponent<PlayerBehavior>().isGrounded) {
			Kick ();
		}
	}

	void Kick () {
		Instantiate (Pow, transform.GetChild (0).transform.position, Quaternion.identity);

		// debug way to get some kicking power around here
		if (transform.parent.GetComponent<PlayerBehavior> ().facingRight) {
			hit = Physics2D.Raycast (transform.GetChild(0).transform.position, Vector2.right, 0.1f);
		} else {
			hit = Physics2D.Raycast (transform.GetChild(0).transform.position, -Vector2.right, 0.1f);
		}

		if (hit.collider != null) {
			Destroy (hit.collider.gameObject);
		}
	}
}
