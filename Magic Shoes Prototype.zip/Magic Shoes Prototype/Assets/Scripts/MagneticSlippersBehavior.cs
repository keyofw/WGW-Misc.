﻿using UnityEngine;
using System.Collections;

public class MagneticSlippersBehavior : MonoBehaviour {

	private bool magnetsOn = false;		// if the magnets are on

	// Use this for initialization
	void Start () {

	}

	void OnEnable () {
		magnetsOn = false;
	}

	void Update () {
		if (Input.GetKeyDown (KeyCode.Space) && GetComponentInParent<PlayerBehavior> ().isGrounded) {
			SwitchMagnet ();
		}
	}

	// this is what switches the functions
	void SwitchMagnet () {
		if (!magnetsOn) {
			magnetsOn = true;
			Debug.Log ("Magnets On. Not sure how to deal with this one.");
		} else {
			magnetsOn = false;
			Debug.Log ("Magnets Off.");
		}
	}
}
