﻿using UnityEngine;
using System.Collections;

public class RocketGreavesBehavior : MonoBehaviour {

	private float rocketForce = 20f;				// how fast you jump

	// Update is called once per frame
	void Update () {
		if (Input.GetKey (KeyCode.Space)) {
			transform.parent.GetComponent<Rigidbody2D> ().AddForce (transform.up * rocketForce);
		}
	}
}
