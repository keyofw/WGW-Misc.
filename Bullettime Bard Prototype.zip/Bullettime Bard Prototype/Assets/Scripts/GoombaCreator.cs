﻿using UnityEngine;
using System.Collections;

public class GoombaCreator : MonoBehaviour {

	public GameObject Goomba;			// get the goombas

	void Start () {
		if (this.gameObject.name == "LeftCreator") {
			InvokeRepeating("CreateGoomba", 3f, 6f);
		} else {
			InvokeRepeating("CreateGoomba", 6f, 6f);
		}
	}

	void CreateGoomba() {
		Instantiate (Goomba, transform.position, Quaternion.identity);
	}
}
