﻿using UnityEngine;
using System.Collections;

public class NoteBehavior : MonoBehaviour {

	public GameObject outline;			// the note outline
	public PlayerBehavior playerScript;	// the script for the player
	public AudioClip noteSound;			// the actual note
	public int spellNumber;				// which number to add to the spell list
	AudioSource audio;					// get the thing to work

	private bool notePlaying;			// whether the note is already playing

	void Awake () {
		audio = GetComponent<AudioSource> ();
		playerScript = GetComponentInParent<PlayerBehavior> ();	
	}

	void OnMouseOver () {
		outline.SetActive (true);
		if (Input.GetMouseButton (0) && !notePlaying) {
			audio.PlayOneShot (noteSound);
			notePlaying = true;
			playerScript.currentSpell.Add (spellNumber);
		}
	}

	void OnMouseExit () {
		outline.SetActive (false);
		audio.Stop ();
		notePlaying = false;
	}

	void Update () {
	
	}
}
