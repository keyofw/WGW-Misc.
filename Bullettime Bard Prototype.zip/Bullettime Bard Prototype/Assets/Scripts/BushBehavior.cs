﻿using UnityEngine;
using System.Collections;

public class BushBehavior : MonoBehaviour {

	public GameObject Fire;					// get the fire which will replace this

	void Start () {
	
	}

	void Update () {
	
	}

	void OnTriggerEnter2D (Collider2D col) {
		if (col.gameObject.tag == "Fireball") {
			Destroy (col.gameObject);
			Instantiate (Fire, transform.position, Quaternion.identity);
			Destroy (this.gameObject);
		}
	}
}
