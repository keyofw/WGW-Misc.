﻿using UnityEngine;
using System.Collections;

public class CameraBehavior : MonoBehaviour {

	public GameObject Player;								// get the player
	private Vector2 currentLocation;						// the camera's current location
	private float speed = 0.07f;									// speed of the cameramovement

	void Start () {
		transform.position = new Vector3 (Player.transform.position.x, Player.transform.position.y + 1f, -10f);
		currentLocation = transform.position;				// set camera location
	}
	
	void Update () {
		currentLocation = transform.position;
		if (transform.position.x - 1f > Player.transform.position.x) {
			currentLocation.x -= speed;
		} else if (transform.position.x + 1f < Player.transform.position.x) {
			currentLocation.x += speed;
		}
		if (transform.position.y -2f > Player.transform.position.y) {
			currentLocation.y -= speed;
		} else if (transform.position.y < Player.transform.position.y) {
			currentLocation.y += speed;
		}
		transform.position = new Vector3 (currentLocation.x, currentLocation.y, -10f);
	}
}
