﻿using UnityEngine;
using System.Collections;

public class CameraBehavior : MonoBehaviour {

	public GameObject Player;								// get the player
	private Vector2 currentLocation;						// the camera's current location

	void Start () {
		transform.position = new Vector3 (Player.transform.position.x, Player.transform.position.y + 1f, -10f);
		currentLocation = transform.position;				// set camera location
	}
	
	void Update () {
		currentLocation = transform.position;
		if (currentLocation.x != Player.transform.position.x) {
			currentLocation.x = Player.transform.position.x;
		}
		if (currentLocation.y != Player.transform.position.y) {
			currentLocation.y = Player.transform.position.y;
		}
		transform.position = new Vector3 (currentLocation.x, currentLocation.y, -10f);
	}
}
