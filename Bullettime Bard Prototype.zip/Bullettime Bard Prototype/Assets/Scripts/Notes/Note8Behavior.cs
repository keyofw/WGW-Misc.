﻿using UnityEngine;
using System.Collections;

public class Note8Behavior : MonoBehaviour {

	public GameObject outline;			// the note outline
	public PlayerBehavior playerScript;	// get the script of the player
	public AudioClip noteSound;			// the actual SFX
	AudioSource audio;			// the source of the audio

	// Use this for initialization
	void Start () {
		audio = GetComponent<AudioSource> ();
		playerScript = GetComponentInParent<PlayerBehavior> ();
	}

	// Update is called once per frame
	void Update () {
		if (Input.GetKeyDown (KeyCode.Alpha8)) {
			playNote ();
			playerScript.currentSpell.Add (8);
		}
		if (Input.GetKeyUp (KeyCode.Alpha8)) {
			stopNote ();
		}
	}

	// this shows the outline and plays the sound while the correct button is pressed
	void playNote () {
		outline.SetActive (true);
		audio.PlayOneShot (noteSound);
	}

	// this stops the note and removes the outline
	void stopNote () {
		outline.SetActive (false);
		audio.Stop ();
	}
}
