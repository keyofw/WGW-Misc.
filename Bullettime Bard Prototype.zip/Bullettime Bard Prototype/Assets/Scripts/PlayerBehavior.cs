﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class PlayerBehavior : MonoBehaviour {

	// get the eight note child objects
	public GameObject note1, note2, note3, note4, note5, note6, note7, note8;
	// other objects
	public GameObject fireball;

	// public
	public float speed = 2.5f;							// how fast the player moves
	public float jumpForce = 300f;						// how fast the player jumps
	public bool facingRight;							// if the player is facing right

	// hidden
	[HideInInspector] public Vector2 currentLocation;	// where is the player
	[HideInInspector] public List<int> currentSpell;	// the notes you put in for a spell

	//private
	private bool musicActivated = false;				// check to see if the ability to use music is active
	private SpriteRenderer sprRend;						// the sprite renderer for the player

	void Start () {
		sprRend = GetComponent<SpriteRenderer> ();
		if (sprRend.flipX == false) {
			facingRight = true;
		} else {
			facingRight = false;
		}
		currentSpell = new List<int>();
	}
	
	void Update () {
		// alternate music activation
		if (Input.GetKeyDown (KeyCode.LeftShift) || Input.GetKeyDown (KeyCode.RightShift)) {
			ActivateMusic ();
		}
		// jump
		if (Input.GetKeyDown (KeyCode.Space)) {
			Jump ();
		}
	}

	void FixedUpdate () {
		// get location and direction
		currentLocation = transform.position;
		float h = Input.GetAxis ("Horizontal");

		//flip sprite
		if (h > 0) {
			facingRight = true;
			sprRend.flipX = false;
		} else if (h < 0) {
			facingRight = false;
			sprRend.flipX = true;
		}

		// actual movement
		currentLocation.x += h * speed * Time.deltaTime * (Time.timeScale/Time.timeScale);
		transform.position = currentLocation;
	}

	// this just switches whether you can use music or not
	void ActivateMusic () {
		if (musicActivated) {
			musicActivated = false;
			// remove the eight notes
			note1.SetActive (false);	note2.SetActive (false);		note3.SetActive (false);	note4.SetActive (false);
			note5.SetActive (false);	note6.SetActive (false);		note7.SetActive (false);	note8.SetActive (false);
			// speed up time
			Time.timeScale = 1.0f;
			// figure out if you made a legit spell
			CheckSpell ();
			// clear list
			currentSpell.Clear();
		} else {
			musicActivated = true;
			// activate the eight notes
			note1.SetActive (true);		note2.SetActive (true);		note3.SetActive (true);		note4.SetActive (true);
			note5.SetActive (true);		note6.SetActive (true);		note7.SetActive (true);		note8.SetActive (true);
			// slow down time
			Time.timeScale = 0.2f;
		}
	}

	// gets the character to Jump
	void Jump () {
		GetComponent<Rigidbody2D> ().AddForce (transform.up * jumpForce);
	}

	void CheckSpell () {
		switch (currentSpell [0])
		{
		case 1:
			switch (currentSpell [1])
			{
			case 3:
				switch (currentSpell [2])
				{
				case 5:
					if (currentSpell.Count == 3) {
						if (!facingRight) {
							Instantiate (fireball, new Vector2 ((transform.position.x - 0.75f), transform.position.y), Quaternion.identity);
						} else if (facingRight) {
							Instantiate (fireball, new Vector2 ((transform.position.x + 0.75f), transform.position.y), Quaternion.identity);
						}
					}
					break;
				default:
					break;
				}
				break;
			default:
				break;
			}
			break;
		default:
			break;
		}
	}
}
