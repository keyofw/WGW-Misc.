﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class PlayerBehavior : MonoBehaviour {

	// get the eight note child objects
	public GameObject note1, note2, note3, note4, note5, note6, note7, note8;
	// other objects
	public GameObject fireball;
	public GameObject flameJet;

	// public
	public float speed = 6f;							// how fast the player moves
	public float jumpForce = 500f;						// how fast the player jumps
	public bool facingRight;							// if the player is facing right
	public bool isGrounded;								// if the player is on the ground
	public bool doubleJump;								// if the player has used the double-jump feature

	// hidden
	[HideInInspector] public Vector2 currentLocation;	// where is the player
	[HideInInspector] public List<int> currentSpell;	// the notes you put in for a spell

	//private
	private bool musicActivated = false;				// check to see if the ability to use music is active
	private SpriteRenderer sprRend;						// the sprite renderer for the player
	private Rigidbody2D rgbd;							// the sprite's rigidbody

	void Start () {
		sprRend = GetComponent<SpriteRenderer> ();
		if (sprRend.flipX == false) {
			facingRight = true;
		} else {
			facingRight = false;
		}
		currentSpell = new List<int>();
		rgbd = GetComponent<Rigidbody2D> ();
	}
	
	void Update () {
		// detect if player is on ground
		if (Physics2D.Linecast (new Vector2 (transform.position.x - 0.5f, transform.position.y - 0.6f),
			    new Vector2 (transform.position.x + 0.5f, transform.position.y - 0.6f))) {
			isGrounded = true;
			doubleJump = false;
		} else {
			isGrounded = false;
		}
		// detect if player is not moving
		if (Mathf.Abs (rgbd.velocity.y) < 0.1f) {
			if (flameJet.activeInHierarchy) {
				flameJet.SetActive (false);
			}
		}
		// alternate music activation
		if (Input.GetKeyDown (KeyCode.E)) {
			ActivateMusic ();
		}
		// jump
		if (Input.GetKeyDown (KeyCode.Space) && isGrounded) {
			Jump (jumpForce);
		}
		// slow down time
		if (Input.GetKeyDown (KeyCode.LeftShift) || Input.GetKeyDown (KeyCode.RightShift)) {
			ChangeTimeSpeed (0.2f);
		}
		// back to regular speed
		if (Input.GetKeyUp (KeyCode.LeftShift) || Input.GetKeyUp (KeyCode.RightShift)) {
			ChangeTimeSpeed (1.0f);
		}
		// check spell
		if (Input.GetMouseButtonUp (0)) {
			CheckSpell ();
			currentSpell.Clear ();
		}
	}

	void FixedUpdate () {
		// get location and direction
		currentLocation = transform.position;
		float h = Input.GetAxis ("Horizontal");

		//flip sprite
		if (h > 0) {
			facingRight = true;
			sprRend.flipX = false;
		} else if (h < 0) {
			facingRight = false;
			sprRend.flipX = true;
		}

		// actual movement
		currentLocation.x += h * speed * Time.deltaTime;
		transform.position = currentLocation;
	}

	void ChangeTimeSpeed (float timeSpeed) {
		Time.timeScale = timeSpeed;
	}

	// this just switches whether you can use music or not
	void ActivateMusic () {
		if (musicActivated) {
			musicActivated = false;
			// remove the eight notes
			note1.SetActive (false);	note2.SetActive (false);		note3.SetActive (false);	note4.SetActive (false);
			note5.SetActive (false);	note6.SetActive (false);		note7.SetActive (false);	note8.SetActive (false);
		} else {
			musicActivated = true;
			// activate the eight notes
			note1.SetActive (true);		note2.SetActive (true);		note3.SetActive (true);		note4.SetActive (true);
			note5.SetActive (true);		note6.SetActive (true);		note7.SetActive (true);		note8.SetActive (true);
		}
	}

	// gets the character to Jump
	void Jump (float force) {
		rgbd.velocity = Vector2.zero;
		GetComponent<Rigidbody2D> ().AddForce (transform.up * force);
	}

	// this is a less horrible way to do spells
	void CheckSpell () {

		if (currentSpell.Count > 0) {
			// fireball
			if (currentSpell [0] == 1 && currentSpell [1] == 3 && currentSpell [2] == 5 && currentSpell.Count == 3) {
				if (!facingRight) {
					Instantiate (fireball, new Vector2 ((transform.position.x - 0.75f), transform.position.y), Quaternion.identity);
				} else if (facingRight) {
					Instantiate (fireball, new Vector2 ((transform.position.x + 0.75f), transform.position.y), Quaternion.identity);
				}
			}
			// double jump
			else if (currentSpell [0] == 4 && currentSpell [1] == 3 && currentSpell [2] == 2 && currentSpell [3] == 6 && currentSpell.Count == 4) {
				if (!doubleJump) {
					doubleJump = true;
					Jump (jumpForce * 0.9f);
				}
			}
			// jet jump version 1
			else if (currentSpell [0] == 1 && currentSpell [1] == 3 && currentSpell [2] == 5 && currentSpell [3] == 4 &&
			           currentSpell [4] == 3 && currentSpell [5] == 2 && currentSpell [6] == 6 && currentSpell.Count == 7) {
				if (!doubleJump) {
					doubleJump = true;
					Jump (jumpForce * 1.5f);
					flameJet.SetActive (true);
				}
			}
			// jet jump version 2
			else if (currentSpell [0] == 4 && currentSpell [1] == 3 && currentSpell [2] == 2 && currentSpell [3] == 6 &&
			           currentSpell [4] == 1 && currentSpell [5] == 3 && currentSpell [6] == 5 && currentSpell.Count == 7) {
				if (!doubleJump) {
					doubleJump = true;
					Jump (jumpForce * 1.5f);
					flameJet.SetActive (true);
				}
			}
		}
	}
}
