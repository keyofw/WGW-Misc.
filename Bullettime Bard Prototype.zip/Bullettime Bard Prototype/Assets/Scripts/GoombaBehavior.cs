﻿using UnityEngine;
using System.Collections;

public class GoombaBehavior : MonoBehaviour {

	public GameObject Player;			// get the player
	public float speed = 1f;			// goomba's speed
	private Vector2 currentLocation;	// get goomba's location
	private Vector2 playerLocation;		// get the player's location

	void Start () {
		currentLocation = transform.position;
	}

	void Update () {
		// follow player
		Player = GameObject.Find ("Player");
			if (transform.position.x < Player.transform.position.x) {
				currentLocation.x += speed * Time.deltaTime;
			} else if (transform.position.x > Player.transform.position.x) {
				currentLocation.x -= speed * Time.deltaTime;
			}
			transform.position = currentLocation;
	}
}
