﻿using UnityEngine;
using System.Collections;

public class FireballBehavior : MonoBehaviour {

	public GameObject player;
	public PlayerBehavior playerScript;

	private Vector2 currentLocation;				// where the fireball is
	private float fireballSpeed = 5f;				// how fast the fireball moves

	void Start () {
		StartCoroutine (kill());
		player = GameObject.Find ("Player");
		playerScript = player.GetComponent<PlayerBehavior> ();
		if (playerScript.facingRight == false) {
			fireballSpeed *= -1f * Time.deltaTime;
		} else {
			fireballSpeed *= Time.deltaTime;
		}
	}

	IEnumerator kill () {
		yield return new WaitForSeconds(1f);
		Destroy (this.gameObject);
	}

	void OnCollisionEnter2D (Collision2D col) {
		if (col.gameObject.tag == "Enemy") {
			Destroy (col.gameObject);
			Destroy (this.gameObject);
		}
	}

	void Update () {
		currentLocation = transform.position;		
		currentLocation.x += fireballSpeed;
		transform.position = currentLocation;
	}
}
