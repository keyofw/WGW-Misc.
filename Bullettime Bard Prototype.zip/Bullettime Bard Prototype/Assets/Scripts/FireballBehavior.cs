﻿using UnityEngine;
using System.Collections;

public class FireballBehavior : MonoBehaviour {

	public GameObject player;
	public PlayerBehavior playerScript;

	private Vector2 currentLocation;				// where the fireball is
	private float fireballSpeed = 0.25f;			// how fast the fireball moves

	void Start () {
		StartCoroutine (kill());
		player = GameObject.Find ("Player");
		playerScript = player.GetComponent<PlayerBehavior> ();
		if (playerScript.facingRight == false) {
			fireballSpeed *= -1f;
		}
	}

	IEnumerator kill () {
		yield return new WaitForSeconds(1f);
		Destroy (this.gameObject);
	}

	void Update () {
		currentLocation = transform.position;		
		currentLocation.x += fireballSpeed;
		transform.position = currentLocation;
	}
}
